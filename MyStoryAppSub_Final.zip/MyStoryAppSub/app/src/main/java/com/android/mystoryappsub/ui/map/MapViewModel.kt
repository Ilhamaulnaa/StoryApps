package com.android.mystoryappsub.ui.map


import androidx.lifecycle.ViewModel
import com.android.mystoryappsub.data.UserRepository

class MapViewModel(private val userRepository: UserRepository): ViewModel() {

    fun getStoryWithMaps() = userRepository.getMaps()

    fun getStoriesLocations(
        token_key: String,
        location: Int
    ) =
        userRepository.getStoriesLocation(token_key, location)


}