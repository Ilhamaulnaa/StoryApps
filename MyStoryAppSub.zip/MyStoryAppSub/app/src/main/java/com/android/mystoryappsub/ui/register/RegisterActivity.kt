package com.android.mystoryappsub.ui.register

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.android.mystoryappsub.R
import com.android.mystoryappsub.databinding.ActivityRegisterBinding
import com.android.mystoryappsub.ui.ViewModelFactory
import com.android.mystoryappsub.utils.LoadingDialog

class RegisterActivity : AppCompatActivity() {

    private var _binding: ActivityRegisterBinding? = null
    private val binding get() = _binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        playAnimation()

        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.title = resources.getString(R.string.register)
        val loadingDialog: LoadingDialog = LoadingDialog(this@RegisterActivity)
        val factory: ViewModelFactory = ViewModelFactory.getInstance(this@RegisterActivity)
        val viewModel: RegisterViewModel by viewModels {
            factory
        }
        binding?.apply {
            btnRegister.setOnClickListener {
                if(edRegisterName.text!!.isNotEmpty() && edRegisterEmail.text!!.isNotEmpty() && edRegisterPassword.text!!.isNotEmpty()){
                    loadingDialog.startLoadingDialog()
                    viewModel.postRegister(
                        edRegisterName.text.toString(),
                        edRegisterEmail.text.toString(),
                        edRegisterPassword.text.toString(),
                        this@RegisterActivity,
                        loadingDialog
                    )
                } else {
                    Toast.makeText(this@RegisterActivity, resources.getString(R.string.empty_input), Toast.LENGTH_SHORT).show()
                }

            }
        }
    }

    private fun playAnimation(){

        val welcome = ObjectAnimator.ofFloat(binding?.tvTitleSignin, View.ALPHA, 1f).setDuration(600)
        val subtitle = ObjectAnimator.ofFloat(binding?.tvSubtitleSignin, View.ALPHA, 1f).setDuration(600)
        val name = ObjectAnimator.ofFloat(binding?.layoutEdRegisterName, View.ALPHA, 1f).setDuration(600)
        val email = ObjectAnimator.ofFloat(binding?.layoutEdRegisterEmail, View.ALPHA, 1f).setDuration(600)
        val password = ObjectAnimator.ofFloat(binding?.layoutEdRegisterPassword, View.ALPHA, 1f).setDuration(600)
        val button = ObjectAnimator.ofFloat(binding?.btnRegister, View.ALPHA, 1f).setDuration(600)
        val register = ObjectAnimator.ofFloat(binding?.btnGotoLogin, View.ALPHA, 1f).setDuration(600)
        val textRegister = ObjectAnimator.ofFloat(binding?.textLogin, View.ALPHA, 1f).setDuration(600)


        AnimatorSet().apply {
            playSequentially(welcome,subtitle,name, email, password, button, textRegister, register)
            start()
        }
    }

    companion object {
        const val NAME_ACTIVITY = "RegisterActivity"
    }
}