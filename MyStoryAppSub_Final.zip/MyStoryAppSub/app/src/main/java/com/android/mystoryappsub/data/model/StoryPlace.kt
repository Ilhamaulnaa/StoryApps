package com.android.mystoryappsub.data.model

data class StoryPlace (
    val name: String,
    val latitude: Double,
    val longitude: Double
)