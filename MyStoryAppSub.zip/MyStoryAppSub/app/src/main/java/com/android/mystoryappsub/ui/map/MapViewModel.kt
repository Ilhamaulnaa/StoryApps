package com.android.mystoryappsub.ui.map


import androidx.lifecycle.ViewModel
import com.android.mystoryappsub.data.UserRepository

class MapViewModel(private val userRepository: UserRepository): ViewModel() {

    fun getStoryWithMaps() = userRepository.getMaps()


}