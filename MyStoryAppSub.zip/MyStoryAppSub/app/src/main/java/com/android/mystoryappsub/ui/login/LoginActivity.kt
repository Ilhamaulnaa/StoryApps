package com.android.mystoryappsub.ui.login

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.android.mystoryappsub.R
import com.android.mystoryappsub.databinding.ActivityLoginBinding
import com.android.mystoryappsub.ui.ViewModelFactory
import com.android.mystoryappsub.ui.register.RegisterActivity
import com.android.mystoryappsub.utils.LoadingDialog
import com.android.mystoryappsub.utils.SharedPreferencesManager

class LoginActivity : AppCompatActivity() {
    private var _binding: ActivityLoginBinding? = null
    private val binding get() = _binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding?.root)
        val userPref = SharedPreferencesManager(this)
        playAnimation()

        val factory: ViewModelFactory = ViewModelFactory.getInstance(this@LoginActivity)
        val viewModel: LoginViewModel by viewModels {
            factory
        }

        val actionBar = supportActionBar
        actionBar?.hide()
        val loadingDialog: LoadingDialog = LoadingDialog(this@LoginActivity)

        binding?.apply {
            Log.d(NAME_ACTIVITY, edLoginEmail.text.toString())
            btnGotoRegister.setOnClickListener {
                val move = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(move)
            }

            btnLogin.setOnClickListener {
                if(edLoginEmail.text!!.isNotEmpty() ){
                    loadingDialog.startLoadingDialog()
                    viewModel.loginUser(
                        edLoginEmail.text.toString(),
                        edLoginPassword.text.toString(),
                        this@LoginActivity,
                        loadingDialog,
                        userPref
                    )
                } else {
                    Toast.makeText(this@LoginActivity, resources.getString(R.string.empty_input), Toast.LENGTH_SHORT).show()
                }

            }
        }
    }

    private fun playAnimation(){

        val welcome = ObjectAnimator.ofFloat(binding?.tvTitleSignin, View.ALPHA, 1f).setDuration(600)
        val email = ObjectAnimator.ofFloat(binding?.layoutEdLoginEmail, View.ALPHA, 1f).setDuration(600)
        val password = ObjectAnimator.ofFloat(binding?.layoutEdLoginPassword, View.ALPHA, 1f).setDuration(600)
        val button = ObjectAnimator.ofFloat(binding?.btnLogin, View.ALPHA, 1f).setDuration(600)
        val register = ObjectAnimator.ofFloat(binding?.btnGotoRegister, View.ALPHA, 1f).setDuration(600)
        val textRegister = ObjectAnimator.ofFloat(binding?.textRegister, View.ALPHA, 1f).setDuration(600)


        AnimatorSet().apply {
            playSequentially(welcome, email, password, button, textRegister, register)
            start()
        }
    }



    companion object {
        const val NAME_ACTIVITY = "Login4ctivity"
    }
}