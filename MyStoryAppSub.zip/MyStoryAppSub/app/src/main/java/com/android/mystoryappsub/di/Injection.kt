package com.android.mystoryappsub.di

import android.content.Context
import com.android.mystoryappsub.data.UserRepository
import com.android.mystoryappsub.data.remote.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val apiService = ApiConfig.getApiServices()
        return UserRepository.getInstance(apiService)
    }
}