package com.android.mystoryappsub.ui.login

import androidx.lifecycle.ViewModel
import com.android.mystoryappsub.data.UserRepository
import com.android.mystoryappsub.utils.LoadingDialog
import com.android.mystoryappsub.utils.SharedPreferencesManager

class LoginViewModel(private val userRepository: UserRepository) : ViewModel() {
    fun loginUser(
        email: String,
        password: String,
        activity: LoginActivity,
        loadingDialog: LoadingDialog,
        userPref: SharedPreferencesManager
    ) =
        userRepository.loginUser(email, password, activity, loadingDialog, userPref)
}